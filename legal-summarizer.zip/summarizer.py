# Summarizer logic placeholder
def summarize_text(text): return text[:200]