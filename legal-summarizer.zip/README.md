# Legal Summarizer App
This app summarizes Supreme Court orders and extracts citations.